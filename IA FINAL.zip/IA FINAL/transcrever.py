import whisper
import openai

audio = whisper.load_model("base")

texto = audio.transcribe("Gravando.m4a")

resumo = texto['text']
with open("ResumoAudio.txt", "w") as arquivo:
       arquivo.write(resumo)

chave_api = "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"
openai.api_key = chave_api

def enviar_conversa(mensagem):
    
    resposta = openai.ChatCompletion.create(

        model = "gpt-3.5-turbo",
        messages = [{"role":"user", "content":mensagem}],
    )
    return resposta["choices"][0]["message"]


novo = "faça um resumo do seguinte texto e gere um relatório detalhado sobre os principais pontos: "+ resumo 

print(enviar_conversa(novo))